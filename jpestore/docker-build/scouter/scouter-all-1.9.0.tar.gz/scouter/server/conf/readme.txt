- Scouter includes ASM library
  http://asm.ow2.org
  Copyright (c) 2000-2011 INRIA, France Telecom

- Scouter includes Javassist library
  http://jboss-javassist.github.io/javassist/
  Copyright (C) 1999- by Shigeru Chiba, All rights reserved

- Scouter includes Byte Buddy library
  http://bytebuddy.net/
  https://github.com/raphw/byte-buddy

- Scouter includes libraries from Scala
  scala-compiler.jar
  scala-library.jar
  scala-reflect.jar

- Scouter includes libraries  from Apache HttpClient
  https://hc.apache.org/  

- Scouter includes classes from HyperLogLog
  HyperLogLog is licensed under the Apache License, Version 2.0 
  https://github.com/addthis/stream-lib/
  Copyright (C) 2012 Clearspring Technologies, Inc.

- Scouter includes libraries  JSqlParser
  JSqlParser is licensed under the LGPL V2.1.
  https://github.com/JSQLParser/JSqlParser


- Scouter includes  GeoLite library created by MaxMind, available from
  http://www.maxmind.com
  Copyright (C) 2003 MaxMind LLC.  All Rights Reserved.
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.
  
   Download MaxMind GeoIP Data :  http://geolite.maxmind.com/download/geoip/database/GeoLiteCity.dat.gz
   The GeoLite databases are distributed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. 

- Scouter includes icons from : 
   http://www.famfamfam.com/lab/icons/silk/
